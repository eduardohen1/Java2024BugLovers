package br.com.ehmf.AppProdutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
